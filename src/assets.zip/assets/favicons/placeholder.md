# A placeholder file to keep the directory open between the kit branches

## assets/favicons

For the website favicons. Use the below tool to generate favicons from one image, and paste the code in your base.html:

https://realfavicongenerator.net/

_CS-TODO - Generate favicons, then delete this file_
