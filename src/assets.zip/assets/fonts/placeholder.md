# A placeholder file to keep the directory open between the kit branches

## assets/fonts

A fonts folder that is automatically passed through as part of the kit configuration. We recommend self-hosting your fonts with the below tool:

https://gwfh.mranftl.com/fonts

_CS-TODO - Generate fonts, then delete this file_
