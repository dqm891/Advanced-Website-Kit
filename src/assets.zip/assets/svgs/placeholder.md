# A placeholder file to keep the directory open between the kit branches

## assets/svgs

To keep SVGs separate from images, should you prefer it that way.

_CS-TODO - Delete this file_
