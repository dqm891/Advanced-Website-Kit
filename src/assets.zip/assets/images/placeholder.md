# A placeholder file to keep the directory open between the kit branches

## assets/images

Store of all the images used in the project

_CS-TODO - Delete this file_
