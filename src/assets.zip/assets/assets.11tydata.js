// Excludes all asset files from being in eleventy collections
module.exports = () => {
    return {
        eleventyExcludeFromCollections: true,
    };
};
